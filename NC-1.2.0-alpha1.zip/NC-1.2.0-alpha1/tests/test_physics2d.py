from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nc_physics2d import World2D
from nc_runtime_support import NCConfigurationError


class Physics2DTests(unittest.TestCase):
    def test_force_and_impulse_obey_mass(self):
        world = World2D({"gravity": [0, 0], "fixed_step": 0.1})
        body = world.circle(0.5, 2.0, [0, 0], {"linear_damping": 0})
        body.apply_force([4, 0])
        world.step()
        self.assertAlmostEqual(body.velocity()[0], 0.2, places=10)
        body.apply_impulse([2, 0])
        self.assertAlmostEqual(body.velocity()[0], 1.2, places=10)

    def test_falling_circle_stops_on_static_floor(self):
        world = World2D({"fixed_step": 1 / 240})
        world.static_box(20, 1, [0, -1])
        ball = world.circle(0.5, 1, [0, 3], {"material": {"restitution": 0}})
        world.simulate(2)
        self.assertGreaterEqual(ball.position()[1], -0.002)
        self.assertLess(abs(ball.velocity()[1]), 0.02)

    def test_same_inputs_are_deterministic(self):
        def run_once():
            world = World2D({"fixed_step": 1 / 120})
            world.static_box(10, 1, [0, -2])
            body = world.box(0.8, 0.8, 1, [0.2, 2], {"angle": 0.2})
            body.apply_impulse([1.2, 0.5], [0.2, 2.3])
            world.simulate(1.25)
            return body.position(), body.velocity(), body.angle(), body.angular_velocity()

        self.assertEqual(run_once(), run_once())

    def test_concave_polygons_are_rejected(self):
        world = World2D()
        with self.assertRaises(NCConfigurationError):
            world.polygon([[0, 0], [2, 0], [1, 0.5], [2, 2], [0, 2]])

    def test_distance_joint_pulls_stretched_bodies_together(self):
        world = World2D({"gravity": [0, 0], "fixed_step": 1 / 240})
        first = world.circle(0.2, 1, [0, 0], {"linear_damping": 0})
        second = world.circle(0.2, 1, [3, 0], {"linear_damping": 0})
        world.distance_joint(first, second, 1.0, 30.0, 8.0)
        initial = math.dist(first.position(), second.position())
        world.simulate(0.5)
        self.assertLess(math.dist(first.position(), second.position()), initial)


if __name__ == "__main__":
    unittest.main()
