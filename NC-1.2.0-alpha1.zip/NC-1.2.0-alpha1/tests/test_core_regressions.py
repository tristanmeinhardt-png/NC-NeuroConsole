from __future__ import annotations

import contextlib
import io
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import nc


class CoreRegressionTests(unittest.TestCase):
    def run_program(self, code: str):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            env = nc.run_text(code, enable_ui=False, source_name="regression.nc")
        return env, output.getvalue()

    def test_variables_condition_loop_and_function(self):
        env, output = self.run_program(
            "\n".join(
                [
                    "let total = 0",
                    "for value in range(1, 5):",
                    "  set total = total + value",
                    "fn double(value):",
                    "  ret value * 2",
                    "if total == 10:",
                    "  print double(total)",
                    "else:",
                    '  print "bad"',
                ]
            )
        )
        self.assertEqual(env["total"], 10)
        self.assertEqual(output.strip(), "20")

    def test_keyword_aliases_remain_supported(self):
        _env, output = self.run_program(
            "\n".join(
                [
                    "print = show",
                    "if = when_custom",
                    "let enabled = True",
                    "when_custom enabled:",
                    '  show "ok"',
                ]
            )
        )
        self.assertEqual(output.strip(), "ok")

    def test_builtin_json_round_trip(self):
        env, _output = self.run_program(
            "\n".join(
                [
                    "import json",
                    'let encoded = json.encode({"name": "NC", "count": 2})',
                    "let decoded = json.parse(encoded)",
                ]
            )
        )
        self.assertEqual(env["decoded"], {"name": "NC", "count": 2})

    def test_local_module_import_and_source_context(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "helper.nc").write_text("let answer = 42\nexport answer\n", encoding="utf-8")
            source = root / "main.nc"
            source.write_text("import helper\nprint helper.answer\n", encoding="utf-8")
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                env = nc.run_file(str(source), enable_ui=False)
        self.assertEqual(output.getvalue().strip(), "42")
        self.assertEqual(env["helper"].get("answer"), 42)

    def test_private_attribute_access_remains_blocked(self):
        with self.assertRaises(nc.NCError) as captured:
            nc.run_text("print ui.__class__\n", enable_ui=False, source_name="private.nc")
        self.assertIn("blocked", captured.exception.message.lower())

    def test_checkmark_on_off_expression_normalization(self):
        env, output = self.run_program(
            "let selected = True\nif selected is on:\n  print \"enabled\"\n"
        )
        self.assertTrue(env["selected"])
        self.assertEqual(output.strip(), "enabled")

    def test_ai_first_preprocessing_still_runs_through_single_run_text(self):
        env, _output = self.run_program('model "local-test"\nlet selected_model = model_api.current()\n')
        self.assertEqual(env["selected_model"], "local-test")


if __name__ == "__main__":
    unittest.main()
