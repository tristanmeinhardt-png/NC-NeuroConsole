from __future__ import annotations

import contextlib
import io
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import nc
import nc_console


class NCIntegrationTests(unittest.TestCase):
    def test_native_physics_modules_import_from_nc(self):
        env = nc.run_text(
            "\n".join(
                [
                    "import physics2d",
                    'let world = physics2d.world({"gravity": [0, 0], "fixed_step": 0.1})',
                    'let body = world.circle(0.5, 2, [0, 0], {"linear_damping": 0})',
                    "body.apply_force([4, 0])",
                    "world.step()",
                ]
            ),
            enable_ui=False,
            source_name="integration_physics.nc",
        )
        self.assertAlmostEqual(env["body"].velocity()[0], 0.2, places=10)

    def test_ui_app_zero_argument_callback(self):
        env = nc.run_text(
            "\n".join(
                [
                    "import ui",
                    'let app = ui.app("Counter")',
                    'let window = app.window("Counter", 640, 360)',
                    'let output = window.text("0")',
                    'let button = window.button("Add")',
                    "fn add_one():",
                    "  output.set_text(str(int(output.text()) + 1))",
                    "button.on_click(add_one)",
                    "button.click()",
                ]
            ),
            enable_ui=False,
            source_name="integration_ui.nc",
        )
        self.assertEqual(env["output"].text(), "1")

    def test_parse_diagnostics_link_cascading_indent_error(self):
        output = io.StringIO()
        with self.assertRaises(nc.NCMultiError) as captured, contextlib.redirect_stdout(output):
            nc.run_text(
                'let alive = True\nif alive\n  print "yes"\n',
                enable_ui=False,
                source_name="missing_colon.nc",
            )
        self.assertEqual(output.getvalue(), "")
        formatted = nc.format_exception(captured.exception)
        self.assertIn("NC-S1001", formatted)
        self.assertIn("consequence of the missing ':'", formatted)
        self.assertIn("Write `if alive:`", formatted)

    def test_runtime_diagnostic_has_nc_call_stack(self):
        with self.assertRaises(nc.NCError) as captured:
            nc.run_text(
                "fn fail():\n  let result = 1 / 0\nfail()\n",
                enable_ui=False,
                source_name="stack.nc",
            )
        formatted = nc.format_exception(captured.exception)
        self.assertIn("NC-R4010", formatted)
        self.assertIn("at fail (stack.nc:1)", formatted)
        self.assertIn("stack.nc:2", formatted)

    def test_no_log_option_does_not_read_text_before_loading_file(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "simple.nc"
            source.write_text('print "ok"\n', encoding="utf-8")
            output = io.StringIO()
            with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
                result = nc_console.main([str(source), "--no-log", "--no-ui"])
        self.assertEqual(result, 0)
        self.assertIn("ok", output.getvalue())


if __name__ == "__main__":
    unittest.main()
