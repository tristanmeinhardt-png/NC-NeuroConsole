from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from nc_physics3d import World3D, create_nc_module


class Physics3DAndClothTests(unittest.TestCase):
    def test_sphere_stops_on_plane(self):
        world = World3D({"fixed_step": 1 / 240})
        world.plane()
        ball = world.sphere(0.5, 1, [0, 0, 3], {"material": {"restitution": 0}})
        world.simulate(2)
        self.assertGreaterEqual(ball.position()[2], 0.498)
        self.assertLess(abs(ball.velocity()[2]), 0.02)

    def test_force_and_torque_are_mass_based(self):
        world = World3D({"gravity": [0, 0, 0], "fixed_step": 0.1})
        body = world.box([2, 1, 1], 2, [0, 0, 0], {"linear_damping": 0, "angular_damping": 0})
        body.apply_force([4, 0, 0])
        body.apply_torque([0, 0, 1])
        world.step()
        self.assertAlmostEqual(body.velocity()[0], 0.2, places=10)
        self.assertGreater(body.angular_velocity()[2], 0)

    def test_horizontal_cloth_sags_but_pins_remain_fixed(self):
        world = World3D({"fixed_step": 1 / 240})
        cloth = world.cloth(
            {
                "columns": 7,
                "rows": 7,
                "size": [3, 3],
                "origin": [-1.5, -1.5, 4],
                "orientation": "horizontal",
                "pinned": "top_corners",
                "solver_iterations": 10,
                "substeps": 2,
            }
        )
        before = cloth.vertices()
        world.simulate(0.75)
        after = cloth.vertices()
        self.assertEqual(after[0], before[0])
        self.assertEqual(after[cloth.columns - 1], before[cloth.columns - 1])
        centre = (cloth.rows // 2) * cloth.columns + cloth.columns // 2
        self.assertLess(after[centre][2], before[centre][2] - 0.05)

    def test_cloth_contract_excludes_other_soft_matter(self):
        class Interpreter:
            _base_dir_current = "."

        features = create_nc_module(Interpreter())["features"]
        self.assertTrue(features["cloth"])
        self.assertFalse(features["generic_soft_bodies"])
        self.assertFalse(features["liquids"])
        self.assertFalse(features["gases"])

    def test_world_is_deterministic_with_cloth(self):
        def run_once():
            world = World3D({"fixed_step": 1 / 120})
            cloth = world.cloth(
                {
                    "columns": 5,
                    "rows": 4,
                    "orientation": "vertical",
                    "origin": [-1, 0, 3],
                    "size": [2, 1.5],
                    "wind": [0, 3, 0],
                }
            )
            world.simulate(0.3)
            return cloth.vertices()

        self.assertEqual(run_once(), run_once())


if __name__ == "__main__":
    unittest.main()
