import ui

let app = ui.app("NC Counter")
let window = app.window("NC Counter", 520, 300)
let heading = window.text("A directly programmed NC window", {"style": {"font_size": 22, "bold": True}})
let output = window.text("0", {"style": {"font_size": 38, "color": "#38bdf8"}})
let controls = window.row()
let add_button = controls.button("Add 1")
let reset_button = controls.button("Reset")

fn add_one():
  output.set_text(str(int(output.text()) + 1))

fn reset():
  output.set_text("0")

add_button.on_click(add_one)
reset_button.on_click(reset)
app.run()
