import physics3d

let world = physics3d.world({
  "gravity": [0, 0, -9.80665],
  "fixed_step": 0.008333333333333333,
  "solver_iterations": 10
})

let ground = world.plane([0, 0, 1], 0)
let pole = world.static_box([0.18, 0.18, 5], [-2.1, 0, 2.5], {"color": "#94a3b8"})

let flag = world.cloth({
  "columns": 24,
  "rows": 15,
  "size": [3.8, 2.2],
  "origin": [-2, 0, 4.8],
  "orientation": "vertical",
  "pinned": "top",
  "mass": 0.9,
  "wind": [0, 5.5, 0.4],
  "structural_stiffness": 0.96,
  "shear_stiffness": 0.82,
  "bend_stiffness": 0.3,
  "color": "#ef4444"
})

let app = physics3d.app(world, {
  "title": "NC 3D Cloth Physics",
  "width": 1200,
  "height": 800,
  "camera_position": [8, -12, 7],
  "camera_target": [0, 0, 2.3]
})
app.run()
