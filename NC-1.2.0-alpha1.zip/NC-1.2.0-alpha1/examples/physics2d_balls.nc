import physics2d

let world = physics2d.world({
  "gravity": [0, -9.80665],
  "fixed_step": 0.008333333333333333,
  "solver_iterations": 10
})

let floor = world.static_box(18, 1, [0, -4], {
  "color": "#475569",
  "material": {"friction": 0.8, "restitution": 0.05}
})

let ball = world.circle(0.55, 1.2, [-1.5, 3], {
  "color": "#38bdf8",
  "material": {"friction": 0.45, "restitution": 0.72}
})

let crate = world.box(1.2, 1.2, 4.0, [1.2, 1.5], {
  "color": "#f59e0b",
  "angle": 0.18,
  "material": {"friction": 0.7, "restitution": 0.1}
})

let app = physics2d.app(world, {
  "title": "NC Real Physics 2D",
  "width": 1100,
  "height": 720,
  "pixels_per_metre": 75,
  "background": "#0b1020"
})
app.run()
